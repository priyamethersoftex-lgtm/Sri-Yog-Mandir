// Exported colors for use in JS logic if needed, though Tailwind is preferred
export const colors = {
  saffron: {
    50: '#fff8ed',
    100: '#ffefd5',
    200: '#ffdbab',
    300: '#ffc069',
    400: '#ffa028',
    500: '#f58220', 
    600: '#d96b0c',
    700: '#b85300',
    800: '#914008',
    900: '#75360b',
    950: '#3f1904',
  },
  plum: {
    50: '#f8f3fa',
    100: '#f0e2f5',
    200: '#e1caeb',
    300: '#cba5dc',
    400: '#ae76c6',
    500: '#9453ab',
    600: '#793e8e',
    700: '#5e3a6e',
    800: '#4a2e56',
    900: '#2d1836', 
    950: '#160b1e',
  },
  cream: {
    50: '#ffffff',
    100: '#faf6f2',
    200: '#f4ece4',
    300: '#eae0d6',
    400: '#dcd1c6',
    500: '#c5b8ac',
  },
  semantic: {
    success: '#22c55e',
    warning: '#f59e0b',
    danger: '#ef4444',
    info: '#3b82f6',
  }
};
