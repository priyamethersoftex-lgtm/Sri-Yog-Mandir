import React, { useEffect, useState } from 'react';
import { dashboardService, DashboardStats } from '../../services/dashboardService';
import { Card, CardContent } from '../../components/ui/Card';
import { LoadingState } from '../../components/data/LoadingState';
import { BedDouble, CheckCircle, Clock, Users, ArrowDownToLine, ArrowUpFromLine, Calendar, Wrench } from 'lucide-react';
import { format } from 'date-fns';

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const data = await dashboardService.getStats();
        setStats(data);
      } catch (error) {
        console.error('Failed to load dashboard stats', error);
      } finally {
        setIsLoading(false);
      }
    }
    load();
  }, []);

  if (isLoading || !stats) return <LoadingState />;

  const statCards = [
    { title: 'Available Today', value: stats.availableToday, icon: CheckCircle, color: 'text-semantic-success' },
    { title: 'Occupied Today', value: stats.occupiedToday, icon: BedDouble, color: 'text-saffron-500' },
    { title: "Today's Arrivals", value: stats.arrivalsToday, icon: ArrowDownToLine, color: 'text-semantic-info' },
    { title: "Today's Departures", value: stats.departuresToday, icon: ArrowUpFromLine, color: 'text-semantic-warning' },
  ];

  const secondaryCards = [
    { title: 'Checked-In Guests', value: stats.checkedInGuests, icon: Users },
    { title: 'Pending Reservations', value: stats.pendingReservations, icon: Clock },
    { title: 'Confirmed Reservations', value: stats.confirmedReservations, icon: Calendar },
    { title: 'Under Maintenance', value: stats.maintenanceToday, icon: Wrench },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-heading font-semibold text-text-primary">Dashboard</h1>
        <p className="text-text-secondary mt-1">{format(new Date(), 'EEEE, MMMM do, yyyy')}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, i) => (
          <Card key={i} className="hover:border-saffron-400 transition-colors">
            <CardContent className="p-6 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-secondary">{stat.title}</p>
                <p className="text-3xl font-bold text-text-primary mt-2">{stat.value}</p>
              </div>
              <div className={`p-4 rounded-full bg-background ${stat.color}`}>
                <stat.icon size={24} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {secondaryCards.map((stat, i) => (
          <Card key={i} className="bg-background/50 border-theme border-dashed">
            <CardContent className="p-6 flex items-center gap-4">
              <div className="p-3 rounded-lg bg-surface text-text-secondary shadow-sm">
                <stat.icon size={20} />
              </div>
              <div>
                <p className="text-2xl font-semibold text-text-primary">{stat.value}</p>
                <p className="text-sm text-text-secondary">{stat.title}</p>
              </div>
            </CardContent>
          </Card>
        ))}
        
        <Card className="bg-background/50 border-theme border-dashed">
          <CardContent className="p-6 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-surface text-text-secondary shadow-sm">
              <BedDouble size={20} />
            </div>
            <div>
              <p className="text-2xl font-semibold text-text-primary">{stats.totalRooms}</p>
              <p className="text-sm text-text-secondary">Total Fixed Rooms</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
