import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Room } from '../../types';
import { roomService } from '../../services/roomService';
import { reservationService } from '../../services/reservationService';
import { FormField } from '../../components/forms/FormField';
import { Button } from '../../components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';
import { ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { addDays, format, differenceInDays } from 'date-fns';

const formSchema = z.object({
  fullName: z.string().min(2, 'Name is required'),
  phone: z.string().min(10, 'Valid phone number required'),
  email: z.string().email('Invalid email address'),
  adults: z.coerce.number().min(1, 'At least 1 adult required'),
  children: z.coerce.number().min(0),
  checkIn: z.string().min(1, 'Check-in date required'),
  checkOut: z.string().min(1, 'Check-out date required'),
  roomId: z.string().min(1, 'Room selection required'),
  source: z.enum(['Website', 'Admin', 'Walk-in']),
  notes: z.string().optional()
}).refine(data => {
  const inDate = new Date(data.checkIn);
  const outDate = new Date(data.checkOut);
  return outDate > inDate;
}, {
  message: "Check-out must be after check-in",
  path: ["checkOut"]
});

type FormData = z.infer<typeof formSchema>;

export default function NewReservation() {
  const navigate = useNavigate();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [availableRoomIds, setAvailableRoomIds] = useState<Set<string>>(new Set());
  const [isCheckingAvailability, setIsCheckingAvailability] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { register, handleSubmit, watch, formState: { errors }, setValue } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      checkIn: format(new Date(), 'yyyy-MM-dd'),
      checkOut: format(addDays(new Date(), 1), 'yyyy-MM-dd'),
      adults: 2,
      children: 0,
      source: 'Admin',
      notes: ''
    }
  });

  const checkIn = watch('checkIn');
  const checkOut = watch('checkOut');
  const selectedRoomId = watch('roomId');
  const adults = watch('adults');
  const children = watch('children');

  useEffect(() => {
    async function loadRooms() {
      const allRooms = await roomService.getRooms();
      setRooms(allRooms);
    }
    loadRooms();
  }, []);

  // Dynamic Availability Check
  useEffect(() => {
    async function checkAvailability() {
      if (!checkIn || !checkOut || new Date(checkOut) <= new Date(checkIn)) {
        setAvailableRoomIds(new Set());
        return;
      }

      setIsCheckingAvailability(true);
      try {
        const available = new Set<string>();
        for (const room of rooms) {
          if (room.isMaintenance) continue;
          
          const isAvail = await reservationService.checkAvailability(room.id, checkIn, checkOut);
          if (isAvail) available.add(room.id);
        }
        setAvailableRoomIds(available);
        
        // Auto-deselect room if it became unavailable
        if (selectedRoomId && !available.has(selectedRoomId)) {
          setValue('roomId', '');
          toast.warning('Selected room is not available for these dates.');
        }
      } finally {
        setIsCheckingAvailability(false);
      }
    }
    
    if (rooms.length > 0) {
      checkAvailability();
    }
  }, [checkIn, checkOut, rooms]);

  const nights = (checkIn && checkOut && new Date(checkOut) > new Date(checkIn)) 
    ? differenceInDays(new Date(checkOut), new Date(checkIn)) 
    : 0;

  const selectedRoom = rooms.find(r => r.id === selectedRoomId);
  const totalAmount = selectedRoom ? selectedRoom.pricePerNight * nights : 0;

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    try {
      await reservationService.createBooking({
        guest: {
          fullName: data.fullName,
          phone: data.phone,
          email: data.email,
          adults: data.adults,
          children: data.children
        },
        stay: {
          checkIn: data.checkIn,
          checkOut: data.checkOut,
          nights,
          roomId: data.roomId
        },
        status: 'Confirmed',
        source: data.source,
        notes: data.notes || ''
      });
      
      toast.success('Reservation created successfully');
      navigate('/reservations');
    } catch (error: any) {
      toast.error(error.message || 'Failed to create reservation');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-4">
        <button 
          onClick={() => navigate('/reservations')}
          className="p-2 hover:bg-surface rounded-full transition-colors text-text-secondary"
        >
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-3xl font-heading font-semibold text-text-primary">New Booking</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Guest Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField label="Full Name" {...register('fullName')} error={errors.fullName?.message} />
              <div className="grid grid-cols-2 gap-4">
                <FormField label="Phone" {...register('phone')} error={errors.phone?.message} />
                <FormField label="Email" type="email" {...register('email')} error={errors.email?.message} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField label="Adults" type="number" {...register('adults')} error={errors.adults?.message} />
                <FormField label="Children" type="number" {...register('children')} error={errors.children?.message} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Stay Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField label="Check-in" type="date" {...register('checkIn')} error={errors.checkIn?.message} />
                <FormField label="Check-out" type="date" {...register('checkOut')} error={errors.checkOut?.message} />
              </div>

              <div className="space-y-1">
                <label className="block text-sm font-medium text-text-secondary">Select Room</label>
                <select 
                  className={`w-full bg-surface border rounded-lg px-3 py-2 text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-saffron-500 ${errors.roomId ? 'border-semantic-danger' : 'border-theme'}`}
                  {...register('roomId')}
                  disabled={isCheckingAvailability}
                >
                  <option value="">Select a room...</option>
                  {rooms.map(room => {
                    const isAvail = availableRoomIds.has(room.id);
                    // Also check capacity if we want to be strict, but keeping it simple for now
                    return (
                      <option key={room.id} value={room.id} disabled={!isAvail}>
                        {room.name} - ₹{room.pricePerNight} / night {!isAvail ? '(Unavailable)' : ''}
                      </option>
                    );
                  })}
                </select>
                {errors.roomId && <p className="text-xs text-semantic-danger mt-1">{errors.roomId.message}</p>}
                {isCheckingAvailability && <p className="text-xs text-saffron-500 mt-1">Checking availability...</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField label="Source" as="select" {...register('source')} error={errors.source?.message}>
                  <option value="Admin">Admin / Phone</option>
                  <option value="Walk-in">Walk-in</option>
                </FormField>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardContent className="p-6">
            <FormField label="Notes" as="textarea" {...register('notes')} />
            
            <div className="mt-6 flex flex-col sm:flex-row justify-between items-center bg-background p-4 rounded-lg border border-theme">
              <div>
                <p className="text-sm text-text-secondary">Summary</p>
                <p className="font-semibold text-text-primary">
                  {nights > 0 ? `${nights} nights` : 'Invalid dates'} 
                  {selectedRoom && ` in ${selectedRoom.name}`}
                </p>
              </div>
              <div className="text-right mt-4 sm:mt-0">
                <p className="text-sm text-text-secondary">Total Amount</p>
                <p className="text-2xl font-bold text-saffron-600">₹{totalAmount.toLocaleString('en-IN')}</p>
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={() => navigate('/reservations')}>Cancel</Button>
              <Button type="submit" isLoading={isSubmitting}>Confirm Booking</Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}
