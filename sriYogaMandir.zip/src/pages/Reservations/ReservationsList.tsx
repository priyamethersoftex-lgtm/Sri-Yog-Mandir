import React, { useEffect, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Booking, BookingStatus } from '../../types';
import { reservationService } from '../../services/reservationService';
import { DataTable, ColumnDef } from '../../components/data/DataTable';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { Button } from '../../components/ui/Button';
import { LoadingState } from '../../components/data/LoadingState';
import { Tabs } from '../../components/ui/Tabs';
import { Card, CardContent } from '../../components/ui/Card';
import { parseISO, format } from 'date-fns';

const TABS = ['All', 'Pending', 'Confirmed', 'Checked In', 'Checked Out', 'Cancelled'];

export default function ReservationsList() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [activeTab, setActiveTab] = useState('All');
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    async function load() {
      try {
        const data = await reservationService.getBookings();
        // Sort descending by created date
        setBookings(data.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      } catch (error) {
        console.error(error);
      } finally {
        setIsLoading(false);
      }
    }
    load();
  }, []);

  const filteredBookings = useMemo(() => {
    if (activeTab === 'All') return bookings;
    return bookings.filter(b => b.status === activeTab);
  }, [bookings, activeTab]);

  const columns: ColumnDef<Booking, any>[] = [
    {
      accessorKey: 'id',
      header: 'Booking ID',
      cell: ({ row }) => <span className="font-semibold text-saffron-600">{row.original.id}</span>
    },
    {
      accessorKey: 'guest',
      header: 'Guest',
      cell: ({ row }) => (
        <div>
          <p className="font-medium text-text-primary">{row.original.guest.fullName}</p>
          <p className="text-xs text-text-secondary">{row.original.guest.phone}</p>
        </div>
      ),
    },
    {
      accessorKey: 'stay',
      header: 'Dates',
      cell: ({ row }) => (
        <div className="text-sm">
          {format(parseISO(row.original.stay.checkIn), 'dd MMM')} - {format(parseISO(row.original.stay.checkOut), 'dd MMM')}
          <span className="text-xs text-text-secondary block">({row.original.stay.nights} nights)</span>
        </div>
      )
    },
    {
      accessorKey: 'totalAmount',
      header: 'Amount',
      cell: ({ row }) => `₹${row.original.totalAmount.toLocaleString('en-IN')}`
    },
    {
      accessorKey: 'status',
      header: 'Status',
      cell: ({ row }) => <StatusBadge status={row.original.status} />
    },
    {
      id: 'actions',
      cell: ({ row }) => (
        <Button variant="outline" size="sm" onClick={() => navigate(`/reservations/${row.original.id}`)}>
          View
        </Button>
      )
    }
  ];

  if (isLoading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
        <div>
          <h1 className="text-3xl font-heading font-semibold text-text-primary">Reservations</h1>
          <p className="text-text-secondary mt-1">Manage all guest bookings and arrivals.</p>
        </div>
        <Button onClick={() => navigate('/reservations/new')}>+ New Booking</Button>
      </div>

      <div className="bg-surface border border-theme rounded-xl shadow-sm overflow-hidden flex flex-col">
        <Tabs tabs={TABS} activeTab={activeTab} onChange={setActiveTab} className="bg-background/50 pt-2 px-4" />
        
        {/* Desktop Table */}
        <div className="hidden md:block">
          <DataTable columns={columns} data={filteredBookings} />
        </div>
        
        {/* Mobile Cards */}
        <div className="md:hidden p-4 space-y-4 bg-background">
          {filteredBookings.length === 0 ? (
            <p className="text-center text-text-secondary py-8">No reservations found.</p>
          ) : (
            filteredBookings.map((booking) => (
              <Card key={booking.id} className="cursor-pointer hover:border-saffron-400 transition-colors" onClick={() => navigate(`/reservations/${booking.id}`)}>
                <CardContent className="p-4 flex flex-col gap-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-semibold text-saffron-600">{booking.id}</span>
                      <h3 className="font-medium text-text-primary mt-1">{booking.guest.fullName}</h3>
                    </div>
                    <StatusBadge status={booking.status} />
                  </div>
                  
                  <div className="flex justify-between items-end text-sm">
                    <div className="text-text-secondary">
                      <p>{format(parseISO(booking.stay.checkIn), 'dd MMM')} - {format(parseISO(booking.stay.checkOut), 'dd MMM')}</p>
                      <p>Room: {booking.stay.roomId}</p>
                    </div>
                    <div className="font-medium">
                      ₹{booking.totalAmount.toLocaleString('en-IN')}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
