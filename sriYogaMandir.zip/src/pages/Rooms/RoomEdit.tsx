import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Room } from '../../types';
import { roomService } from '../../services/roomService';
import { Button } from '../../components/ui/Button';
import { FormField } from '../../components/forms/FormField';
import { LoadingState } from '../../components/data/LoadingState';
import { toast } from 'sonner';
import { ArrowLeft, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';
import { ConfirmationDialog } from '../../components/ui/ConfirmationDialog';

export default function RoomEdit() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [room, setRoom] = useState<Room | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isMaintenanceDialogOpen, setIsMaintenanceDialogOpen] = useState(false);

  useEffect(() => {
    async function load() {
      if (!id) return;
      try {
        const data = await roomService.getRoom(id);
        setRoom(data);
      } catch (error) {
        toast.error('Failed to load room');
        navigate('/rooms');
      } finally {
        setIsLoading(false);
      }
    }
    load();
  }, [id, navigate]);

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!room) return;
    
    setIsSaving(true);
    try {
      const formData = new FormData(e.currentTarget);
      
      const updated: Room = {
        ...room,
        pricePerNight: Number(formData.get('pricePerNight')),
        originalPrice: Number(formData.get('originalPrice')),
        category: formData.get('category') as any,
        nameHi: formData.get('nameHi') as string,
        view: formData.get('view') as string,
        floor: formData.get('floor') as string,
        bedType: formData.get('bedType') as string,
        sizeSqFt: Number(formData.get('sizeSqFt')),
        capacity: {
          adults: Number(formData.get('adults')),
          children: Number(formData.get('children')),
        },
        tagline: formData.get('tagline') as string,
        shortDescription: formData.get('shortDescription') as string,
        description: formData.get('description') as string,
      };

      await roomService.updateRoom(updated);
      setRoom(updated);
      toast.success('Room updated successfully');
    } catch (error) {
      toast.error('Failed to update room');
    } finally {
      setIsSaving(false);
    }
  };

  const toggleMaintenance = async () => {
    if (!room) return;
    setIsSaving(true);
    try {
      const updated = { ...room, isMaintenance: !room.isMaintenance };
      await roomService.updateRoom(updated);
      setRoom(updated);
      toast.success(`Room marked as ${updated.isMaintenance ? 'Maintenance' : 'Available'}`);
      setIsMaintenanceDialogOpen(false);
    } catch (error) {
      toast.error('Failed to update status');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading || !room) return <LoadingState />;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-4">
        <button 
          onClick={() => navigate('/rooms')}
          className="p-2 hover:bg-surface rounded-full transition-colors text-text-secondary hover:text-text-primary"
        >
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-3xl font-heading font-semibold text-text-primary">Edit Room: {room.name}</h1>
          <p className="text-text-secondary mt-1">ID: {room.id} (Locked)</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <form onSubmit={handleSave} className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField label="Hindi Name" name="nameHi" defaultValue={room.nameHi} />
                  <FormField 
                    label="Category" 
                    name="category" 
                    as="select" 
                    defaultValue={room.category}
                    options={[
                      { label: 'Suit River View', value: 'Suit River View' },
                      { label: 'Ganga Deluxe River', value: 'Ganga Deluxe River' },
                      { label: 'Deluxe Non-River View', value: 'Deluxe Non-River View' },
                    ]}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField label="Price per Night (₹)" name="pricePerNight" type="number" defaultValue={room.pricePerNight} />
                  <FormField label="Original Price (₹)" name="originalPrice" type="number" defaultValue={room.originalPrice} />
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <FormField label="Adults" name="adults" type="number" defaultValue={room.capacity.adults} />
                  <FormField label="Children" name="children" type="number" defaultValue={room.capacity.children} />
                  <FormField label="Size (Sq Ft)" name="sizeSqFt" type="number" defaultValue={room.sizeSqFt} />
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <FormField label="View" name="view" defaultValue={room.view} />
                  <FormField label="Floor" name="floor" defaultValue={room.floor} />
                  <FormField label="Bed Type" name="bedType" defaultValue={room.bedType} />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Descriptions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField label="Tagline" name="tagline" defaultValue={room.tagline} />
                <FormField label="Short Description" name="shortDescription" as="textarea" defaultValue={room.shortDescription} />
                <FormField label="Full Description" name="description" as="textarea" defaultValue={room.description} className="min-h-[120px]" />
              </CardContent>
            </Card>

            <div className="flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={() => navigate('/rooms')}>Cancel</Button>
              <Button type="submit" isLoading={isSaving}>Save Changes</Button>
            </div>
          </form>
        </div>

        <div className="space-y-6">
          <Card className={room.isMaintenance ? "border-semantic-danger" : ""}>
            <CardHeader className="bg-background">
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle size={18} className={room.isMaintenance ? "text-semantic-danger" : "text-text-secondary"} />
                Operational Status
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6 text-center space-y-4">
              <p className="text-sm text-text-secondary">
                {room.isMaintenance 
                  ? "This room is currently marked for maintenance and is unavailable for new bookings." 
                  : "Mark this room for maintenance to block it from future bookings."}
              </p>
              <Button 
                variant={room.isMaintenance ? "primary" : "danger"} 
                className="w-full"
                onClick={() => setIsMaintenanceDialogOpen(true)}
              >
                {room.isMaintenance ? "Mark as Available" : "Mark as Maintenance"}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      <ConfirmationDialog 
        isOpen={isMaintenanceDialogOpen}
        onClose={() => setIsMaintenanceDialogOpen(false)}
        onConfirm={toggleMaintenance}
        title={room.isMaintenance ? "Mark Room Available" : "Mark Room for Maintenance"}
        message={room.isMaintenance 
          ? `Are you sure you want to make ${room.name} available for bookings again?` 
          : `Are you sure you want to place ${room.name} under maintenance? This will prevent any new bookings for this room.`}
        confirmText={room.isMaintenance ? "Mark Available" : "Confirm Maintenance"}
        isDestructive={!room.isMaintenance}
        isLoading={isSaving}
      />
    </div>
  );
}
