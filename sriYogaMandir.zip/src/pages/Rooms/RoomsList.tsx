import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Room, RoomStatus } from '../../types';
import { roomService } from '../../services/roomService';
import { DataTable, ColumnDef } from '../../components/data/DataTable';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { Button } from '../../components/ui/Button';
import { LoadingState } from '../../components/data/LoadingState';

interface RoomWithStatus extends Room {
  currentStatus: RoomStatus;
}

export default function RoomsList() {
  const [rooms, setRooms] = useState<RoomWithStatus[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    async function loadRooms() {
      try {
        const data = await roomService.getRooms();
        const withStatus = await Promise.all(
          data.map(async (room) => ({
            ...room,
            currentStatus: await roomService.getRoomStatus(room.id)
          }))
        );
        setRooms(withStatus);
      } catch (error) {
        console.error('Failed to load rooms:', error);
      } finally {
        setIsLoading(false);
      }
    }
    loadRooms();
  }, []);

  const columns: ColumnDef<RoomWithStatus, any>[] = [
    {
      accessorKey: 'name',
      header: 'Room',
      cell: ({ row }) => (
        <div>
          <p className="font-semibold">{row.original.name}</p>
          <p className="text-xs text-text-secondary">{row.original.nameHi}</p>
        </div>
      ),
    },
    {
      accessorKey: 'category',
      header: 'Category',
    },
    {
      accessorKey: 'pricePerNight',
      header: 'Price / Night',
      cell: ({ row }) => `₹${row.original.pricePerNight.toLocaleString('en-IN')}`,
    },
    {
      accessorKey: 'capacity',
      header: 'Capacity',
      cell: ({ row }) => `${row.original.capacity.adults}A, ${row.original.capacity.children}C`,
    },
    {
      accessorKey: 'currentStatus',
      header: 'Status',
      cell: ({ row }) => <StatusBadge status={row.original.currentStatus} />,
    },
    {
      id: 'actions',
      cell: ({ row }) => (
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => navigate(`/rooms/${row.original.id}/edit`)}
        >
          Edit
        </Button>
      ),
    },
  ];

  if (isLoading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-heading font-semibold text-text-primary">Rooms</h1>
          <p className="text-text-secondary mt-1">Manage the {rooms.length} fixed property rooms.</p>
        </div>
      </div>

      <div className="bg-surface border border-theme rounded-xl shadow-sm overflow-hidden">
        <DataTable columns={columns} data={rooms} />
      </div>
    </div>
  );
}
