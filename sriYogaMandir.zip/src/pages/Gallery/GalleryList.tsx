import React, { useEffect, useState, useMemo } from 'react';
import { GalleryItem } from '../../types';
import { galleryService } from '../../services/galleryService';
import { Button } from '../../components/ui/Button';
import { Card, CardContent } from '../../components/ui/Card';
import { LoadingState } from '../../components/data/LoadingState';
import { ConfirmationDialog } from '../../components/ui/ConfirmationDialog';
import { Modal } from '../../components/ui/Modal';
import { FormField } from '../../components/forms/FormField';
import { ImageUploader } from '../../components/forms/ImageUploader';
import { toast } from 'sonner';

const CATEGORIES = ['All', 'Yoga & Meditation', 'Rooms & Suites', 'Dining & Sattvic', 'Spiritual Tours', 'Temple Tour', 'Aarti & Events'];

export default function GalleryList() {
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [activeTab, setActiveTab] = useState('All');
  const [isLoading, setIsLoading] = useState(true);
  
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);
  const [uploadData, setUploadData] = useState<Partial<GalleryItem>>({
    category: 'Rooms & Suites',
    isPublished: true,
  });

  const loadItems = async () => {
    try {
      const data = await galleryService.getGalleryItems();
      setItems(data);
    } catch (error) {
      toast.error('Failed to load gallery');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadItems();
  }, []);

  const filteredItems = useMemo(() => {
    if (activeTab === 'All') return items;
    return items.filter(i => i.category === activeTab);
  }, [items, activeTab]);

  const handleDelete = async () => {
    if (!itemToDelete) return;
    try {
      await galleryService.deleteGalleryItem(itemToDelete);
      toast.success('Image deleted');
      await loadItems();
    } catch (error) {
      toast.error('Failed to delete image');
    } finally {
      setItemToDelete(null);
    }
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadData.url) {
      toast.error('Please select an image');
      return;
    }
    
    try {
      await galleryService.addGalleryItem(uploadData as any);
      toast.success('Image added successfully');
      setIsUploadModalOpen(false);
      setUploadData({ category: 'Rooms & Suites', isPublished: true });
      await loadItems();
    } catch (error) {
      toast.error('Failed to upload image');
    }
  };

  if (isLoading) return <LoadingState />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-heading font-semibold text-text-primary">Gallery</h1>
          <p className="text-text-secondary mt-1">Manage public website images.</p>
        </div>
        <Button onClick={() => setIsUploadModalOpen(true)}>+ Add Image</Button>
      </div>

      <div className="flex space-x-2 overflow-x-auto pb-2 no-scrollbar">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveTab(cat)}
            className={`px-4 py-2 text-sm font-medium rounded-full transition-colors whitespace-nowrap border ${
              activeTab === cat 
                ? 'bg-saffron-500 text-white border-saffron-500' 
                : 'bg-surface text-text-secondary border-theme hover:border-saffron-400'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {filteredItems.map(item => (
          <Card key={item.id} className="overflow-hidden group">
            <div className="relative h-48 bg-background">
              {item.url ? (
                <img src={item.url} alt={item.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-text-secondary">No Image</div>
              )}
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <Button variant="danger" size="sm" onClick={() => setItemToDelete(item.id)}>Delete</Button>
              </div>
            </div>
            <CardContent className="p-4">
              <h3 className="font-semibold text-text-primary truncate">{item.title}</h3>
              <p className="text-sm text-text-secondary truncate mt-1">{item.category}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Modal isOpen={isUploadModalOpen} onClose={() => setIsUploadModalOpen(false)} title="Upload Image">
        <form onSubmit={handleUploadSubmit} className="space-y-4">
          <ImageUploader 
            value={uploadData.url} 
            onChange={(url) => setUploadData({ ...uploadData, url })}
            onRemove={() => setUploadData({ ...uploadData, url: undefined })}
          />
          <FormField 
            label="Title" 
            value={uploadData.title || ''} 
            onChange={e => setUploadData({ ...uploadData, title: e.target.value })} 
            required 
          />
          <FormField 
            label="Category" 
            as="select"
            value={uploadData.category}
            onChange={e => setUploadData({ ...uploadData, category: e.target.value })}
            options={CATEGORIES.filter(c => c !== 'All').map(c => ({ label: c, value: c }))}
          />
          <FormField 
            label="Caption" 
            value={uploadData.caption || ''} 
            onChange={e => setUploadData({ ...uploadData, caption: e.target.value })} 
          />
          <div className="flex justify-end gap-3 mt-6">
            <Button type="button" variant="outline" onClick={() => setIsUploadModalOpen(false)}>Cancel</Button>
            <Button type="submit">Upload</Button>
          </div>
        </form>
      </Modal>

      <ConfirmationDialog 
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        onConfirm={handleDelete}
        title="Delete Image"
        message="Are you sure you want to delete this image? It will be removed from the public website."
        isDestructive
      />
    </div>
  );
}
