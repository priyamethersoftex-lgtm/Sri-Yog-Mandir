import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { Button } from '../../components/ui/Button';
import { FormField } from '../../components/forms/FormField';
import { toast } from 'sonner';

export default function Login() {
  const [email, setEmail] = useState('admin@banarasyogmandir.com');
  const [password, setPassword] = useState('admin123');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    try {
      await login(email, password);
      navigate('/dashboard', { replace: true });
    } catch (error: any) {
      toast.error(error.message || 'Login failed');
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md bg-surface p-8 rounded-2xl shadow-elevated border border-theme">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-heading font-bold text-saffron-500 mb-2">Banaras Yog Mandir</h1>
          <p className="text-text-secondary">Admin Portal Login</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <FormField 
            label="Email Address" 
            type="email" 
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required 
          />
          <FormField 
            label="Password" 
            type="password" 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required 
          />
          
          <div className="pt-4">
            <Button type="submit" className="w-full" isLoading={isLoggingIn}>
              Sign In
            </Button>
          </div>
        </form>

        <div className="mt-6 text-center text-sm text-text-secondary bg-saffron-50 dark:bg-saffron-500/10 p-3 rounded-lg border border-saffron-200 dark:border-saffron-500/20">
          <p className="font-medium text-saffron-700 dark:text-saffron-400 mb-1">Demo Credentials</p>
          <p>Email: admin@banarasyogmandir.com</p>
          <p>Password: admin123</p>
        </div>
      </div>
    </div>
  );
}
