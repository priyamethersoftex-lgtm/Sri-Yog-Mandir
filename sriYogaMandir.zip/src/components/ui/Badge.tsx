import React from 'react';
import { cn } from '../../utils/cn';

interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'outline';
}

export function Badge({ className, variant = 'default', ...props }: BadgeProps) {
  const baseStyles = "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium font-sans";
  
  const variants = {
    default: "bg-background text-text-secondary border border-theme",
    success: "bg-semantic-success/10 text-semantic-success border border-semantic-success/20",
    warning: "bg-semantic-warning/10 text-semantic-warning border border-semantic-warning/20",
    danger: "bg-semantic-danger/10 text-semantic-danger border border-semantic-danger/20",
    info: "bg-semantic-info/10 text-semantic-info border border-semantic-info/20",
    outline: "border border-theme text-text-primary",
  };

  return (
    <div className={cn(baseStyles, variants[variant], className)} {...props} />
  );
}
