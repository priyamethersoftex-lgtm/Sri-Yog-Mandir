import React from 'react';
import { Badge } from './Badge';

// Matches RoomStatus and BookingStatus from types
type StatusType = 
  | 'Available' | 'Reserved' | 'Occupied' | 'Maintenance'
  | 'Pending' | 'Confirmed' | 'Checked In' | 'Checked Out' | 'Cancelled';

interface StatusBadgeProps {
  status: StatusType;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  let variant: 'success' | 'warning' | 'danger' | 'info' | 'default' = 'default';

  switch (status) {
    case 'Available':
    case 'Checked Out':
      variant = 'success';
      break;
    case 'Pending':
    case 'Reserved':
      variant = 'warning';
      break;
    case 'Occupied':
    case 'Checked In':
    case 'Confirmed':
      variant = 'info';
      break;
    case 'Maintenance':
    case 'Cancelled':
      variant = 'danger';
      break;
  }

  return (
    <Badge variant={variant} className={className}>
      {status}
    </Badge>
  );
}
