import React from 'react';
import { cn } from '../../utils/cn';

interface FormFieldProps extends React.InputHTMLAttributes<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement> {
  label: string;
  error?: string;
  as?: 'input' | 'select' | 'textarea';
  options?: { label: string; value: string }[];
}

export const FormField = React.forwardRef<any, FormFieldProps>(
  ({ label, error, className, as = 'input', options, ...props }, ref) => {
    const inputClass = cn(
      "w-full bg-surface border rounded-lg px-3 py-2 text-sm text-text-primary transition-colors focus:outline-none focus:ring-2 focus:ring-saffron-500",
      error ? "border-semantic-danger focus:ring-semantic-danger" : "border-theme focus:border-transparent",
      className
    );

    return (
      <div className="space-y-1">
        <label className="block text-sm font-medium text-text-secondary">
          {label}
        </label>
        
        {as === 'input' && (
          <input ref={ref} className={inputClass} {...(props as any)} />
        )}
        
        {as === 'textarea' && (
          <textarea ref={ref} className={cn(inputClass, "resize-y min-h-[80px]")} {...(props as any)} />
        )}
        
        {as === 'select' && (
          <select ref={ref} className={inputClass} {...(props as any)}>
            {options?.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        )}
        
        {error && (
          <p className="text-xs text-semantic-danger mt-1">{error}</p>
        )}
      </div>
    );
  }
);
FormField.displayName = 'FormField';
