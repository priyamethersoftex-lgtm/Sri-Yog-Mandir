import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, CalendarDays, BedDouble, Image as ImageIcon, Settings, User, X } from 'lucide-react';
import clsx from 'clsx';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const navItems = [
  { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
  { name: 'Reservations', path: '/reservations', icon: CalendarDays },
  { name: 'Rooms', path: '/rooms', icon: BedDouble },
  { name: 'Gallery', path: '/gallery', icon: ImageIcon },
];

const adminItems = [
  { name: 'Profile', path: '/profile', icon: User },
  { name: 'Settings', path: '/settings', icon: Settings },
];

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-20 md:hidden" 
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={clsx(
        "fixed md:static inset-y-0 left-0 z-30 w-64 bg-surface border-r border-theme transform transition-transform duration-200 ease-in-out flex flex-col",
        isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
      )}>
        <div className="h-16 flex items-center justify-between px-6 border-b border-theme">
          <span className="font-heading text-lg font-bold text-saffron-500">Banaras Yog Mandir</span>
          <button className="md:hidden text-text-secondary" onClick={onClose}>
            <X size={20} />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto py-4">
          <nav className="px-4 space-y-1">
            {navItems.map((item) => (
              <NavLink
                key={item.name}
                to={item.path}
                className={({ isActive }) => clsx(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors",
                  isActive 
                    ? "bg-saffron-50 text-saffron-600 dark:bg-saffron-500/10 dark:text-saffron-400" 
                    : "text-text-secondary hover:bg-background hover:text-text-primary"
                )}
              >
                <item.icon size={20} />
                {item.name}
              </NavLink>
            ))}
          </nav>
          
          <div className="mt-8 px-4">
            <h3 className="px-3 text-xs font-semibold text-text-secondary uppercase tracking-wider mb-2">
              Administration
            </h3>
            <nav className="space-y-1">
              {adminItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  className={({ isActive }) => clsx(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg font-medium transition-colors",
                    isActive 
                      ? "bg-saffron-50 text-saffron-600 dark:bg-saffron-500/10 dark:text-saffron-400" 
                      : "text-text-secondary hover:bg-background hover:text-text-primary"
                  )}
                >
                  <item.icon size={20} />
                  {item.name}
                </NavLink>
              ))}
            </nav>
          </div>
        </div>
      </div>
    </>
  );
}
