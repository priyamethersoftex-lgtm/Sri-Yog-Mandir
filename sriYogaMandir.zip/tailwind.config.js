/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        saffron: {
          50: '#fff8ed',
          100: '#ffefd5',
          200: '#ffdbab',
          300: '#ffc069',
          400: '#ffa028',
          500: '#f58220', // Primary accent
          600: '#d96b0c',
          700: '#b85300',
          800: '#914008',
          900: '#75360b',
          950: '#3f1904',
        },
        plum: {
          50: '#f8f3fa',
          100: '#f0e2f5',
          200: '#e1caeb',
          300: '#cba5dc',
          400: '#ae76c6',
          500: '#9453ab',
          600: '#793e8e',
          700: '#5e3a6e',
          800: '#4a2e56',
          900: '#2d1836', // Primary dark text/bg
          950: '#160b1e', // Dark mode background
        },
        cream: {
          50: '#ffffff',
          100: '#faf6f2', // Warm Ivory / Light Background
          200: '#f4ece4',
          300: '#eae0d6',
          400: '#dcd1c6',
          500: '#c5b8ac',
        },
        semantic: {
          success: '#22c55e',
          warning: '#f59e0b',
          danger: '#ef4444',
          info: '#3b82f6',
        },
        background: 'var(--background)',
        surface: 'var(--surface)',
        border: 'var(--border)',
      },
      fontFamily: {
        heading: ['"Playfair Display"', 'serif'],
        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
      },
      boxShadow: {
        'card': '0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03)',
        'elevated': '0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.04)',
      },
    },
  },
  plugins: [],
}
